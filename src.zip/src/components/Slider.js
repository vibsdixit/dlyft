import React from 'react'

const Slider = () => {
  return (
    <div>
      slider
    </div>
  )
}

export default Slider
