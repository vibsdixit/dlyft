import React from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import '../../node_modules/bootstrap/dist/js/bootstrap.js';
import '../../node_modules/bootstrap/dist/js/bootstrap.bundle.js';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';
import {MDBIcon } from "mdbreact";
import '../components/Header.css';
import logo from '../img/logo.png';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
const Header = () => (
  
  <Container fluid>
  
    <Row className='border border-solid'>
      <Col xl={3}  className="mt-4">
      <ol className="list">
      <li>
      <i class="fas fa-video"></i> Video Assistance
      </li>
      <li><i class="fas fa-street-view"></i> Store Locator
      </li>
     </ol>
      </Col>
      <Col xl={6}>
      <div className="input-group md-form form-sm form-1 pl-0">
        
        <input
          className="form-control my-0 py-1"
          type="text"
          placeholder="Search"
          aria-label="Search"
        />
        <div className="input-group-prepend">
          <span className="input-group-text red lighten-3" id="basic-text1">
            <MDBIcon className="text-white" icon="search" />
          </span>
        </div>
      </div>
      
      </Col>
      <Col xl={3} className="mt-4 ">
     <ol className="list">
      <li>
      <i class="fas fa-book-medical"></i>   Register My Bike
      </li>
      <li><i class="fas fa-check-double"> </i> Warranty</li>
     </ol>
    </Col>
    </Row>


  <Row>
    <Col xl={3}  className="mt-4 logo"><img src={logo}/></Col>
    <Col xl={9}>

    <Navbar collapseOnSelect expand="lg" >
      <Container>
        
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#features">Electric Bycycle</Nav.Link>
            
            <NavDropdown title="Bicycle Categories " id="collasible-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Men Bikes</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">Women Bike</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Boys Bike</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.4">Geared Bikes</NavDropdown.Item>
            </NavDropdown>



            <NavDropdown title="Bicycle Types  " id="collasible-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">E Bikes </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">Mountain Bikes </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">All Terrain Bikes</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.4">Hybrid Bikes</NavDropdown.Item>
            </NavDropdown>

            <Nav.Link href="#features">Accessories</Nav.Link>
            <Nav.Link href="#features">Cycling Clothing</Nav.Link>
          </Nav>
          
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </Col>
  </Row>
  </Container>





  )


export default Header;

